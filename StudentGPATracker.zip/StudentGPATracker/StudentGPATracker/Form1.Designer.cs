﻿namespace StudentGPATracker
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            textBox1 = new TextBox();
            textBox2 = new TextBox();
            textBox4 = new TextBox();
            searchTxt = new TextBox();
            saveBtn = new Button();
            loadBtn = new Button();
            calculateBtn = new Button();
            delBtn = new Button();
            filterBtn = new Button();
            addBtn = new Button();
            searchBtn = new Button();
            sidLbl = new Label();
            nameLbl = new Label();
            courseLbl = new Label();
            gradeLbl = new Label();
            gpaLbl = new Label();
            sinfoLbl = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            label11 = new Label();
            searchlbl = new Label();
            comboBox1 = new ComboBox();
            panel1 = new Panel();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // textBox1
            // 
            textBox1.Location = new Point(53, 56);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(168, 56);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(168, 23);
            textBox2.TabIndex = 1;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(511, 55);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(140, 23);
            textBox4.TabIndex = 3;
            // 
            // searchTxt
            // 
            searchTxt.Location = new Point(588, 119);
            searchTxt.Name = "searchTxt";
            searchTxt.Size = new Size(100, 23);
            searchTxt.TabIndex = 4;
            // 
            // saveBtn
            // 
            saveBtn.Location = new Point(53, 118);
            saveBtn.Name = "saveBtn";
            saveBtn.Size = new Size(97, 23);
            saveBtn.TabIndex = 5;
            saveBtn.Text = "Save to File";
            saveBtn.UseVisualStyleBackColor = true;
            // 
            // loadBtn
            // 
            loadBtn.Location = new Point(153, 118);
            loadBtn.Name = "loadBtn";
            loadBtn.Size = new Size(93, 23);
            loadBtn.TabIndex = 6;
            loadBtn.Text = "Load form";
            loadBtn.UseVisualStyleBackColor = true;
            // 
            // calculateBtn
            // 
            calculateBtn.Location = new Point(261, 118);
            calculateBtn.Name = "calculateBtn";
            calculateBtn.Size = new Size(75, 23);
            calculateBtn.TabIndex = 7;
            calculateBtn.Text = "Calculate GPA";
            calculateBtn.UseVisualStyleBackColor = true;
            // 
            // delBtn
            // 
            delBtn.Location = new Point(342, 119);
            delBtn.Name = "delBtn";
            delBtn.Size = new Size(94, 23);
            delBtn.TabIndex = 8;
            delBtn.Text = "Delete Record";
            delBtn.UseVisualStyleBackColor = true;
            // 
            // filterBtn
            // 
            filterBtn.Location = new Point(442, 118);
            filterBtn.Name = "filterBtn";
            filterBtn.Size = new Size(75, 23);
            filterBtn.TabIndex = 9;
            filterBtn.Text = "Filter";
            filterBtn.UseVisualStyleBackColor = true;
            // 
            // addBtn
            // 
            addBtn.Location = new Point(675, 55);
            addBtn.Name = "addBtn";
            addBtn.Size = new Size(101, 23);
            addBtn.TabIndex = 10;
            addBtn.Text = "Add Record";
            addBtn.UseVisualStyleBackColor = true;
            // 
            // searchBtn
            // 
            searchBtn.Location = new Point(694, 119);
            searchBtn.Name = "searchBtn";
            searchBtn.Size = new Size(82, 23);
            searchBtn.TabIndex = 11;
            searchBtn.Text = "Search ID";
            searchBtn.UseVisualStyleBackColor = true;
            // 
            // sidLbl
            // 
            sidLbl.AutoSize = true;
            sidLbl.Location = new Point(53, 38);
            sidLbl.Name = "sidLbl";
            sidLbl.Size = new Size(62, 15);
            sidLbl.TabIndex = 12;
            sidLbl.Text = "Student ID";
            // 
            // nameLbl
            // 
            nameLbl.AutoSize = true;
            nameLbl.Location = new Point(168, 38);
            nameLbl.Name = "nameLbl";
            nameLbl.Size = new Size(39, 15);
            nameLbl.TabIndex = 13;
            nameLbl.Text = "Name";
            // 
            // courseLbl
            // 
            courseLbl.AutoSize = true;
            courseLbl.Location = new Point(354, 37);
            courseLbl.Name = "courseLbl";
            courseLbl.Size = new Size(44, 15);
            courseLbl.TabIndex = 14;
            courseLbl.Text = "Course";
            // 
            // gradeLbl
            // 
            gradeLbl.AutoSize = true;
            gradeLbl.Location = new Point(511, 37);
            gradeLbl.Name = "gradeLbl";
            gradeLbl.Size = new Size(38, 15);
            gradeLbl.TabIndex = 15;
            gradeLbl.Text = "Grade";
            // 
            // gpaLbl
            // 
            gpaLbl.AutoSize = true;
            gpaLbl.Location = new Point(39, 400);
            gpaLbl.Name = "gpaLbl";
            gpaLbl.Size = new Size(32, 15);
            gpaLbl.TabIndex = 16;
            gpaLbl.Text = "GPA:";
            // 
            // sinfoLbl
            // 
            sinfoLbl.AutoSize = true;
            sinfoLbl.Location = new Point(477, 400);
            sinfoLbl.Name = "sinfoLbl";
            sinfoLbl.Size = new Size(299, 15);
            sinfoLbl.TabIndex = 17;
            sinfoLbl.Text = "Programmer By: Mohammed Alluqman - ID: 202536470";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(18, 10);
            label7.Name = "label7";
            label7.Size = new Size(38, 15);
            label7.TabIndex = 18;
            label7.Text = "label7";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(59, 10);
            label8.Name = "label8";
            label8.Size = new Size(38, 15);
            label8.TabIndex = 19;
            label8.Text = "label8";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(158, 10);
            label9.Name = "label9";
            label9.Size = new Size(38, 15);
            label9.TabIndex = 20;
            label9.Text = "label9";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(269, 15);
            label10.Name = "label10";
            label10.Size = new Size(44, 15);
            label10.TabIndex = 21;
            label10.Text = "label10";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(380, 10);
            label11.Name = "label11";
            label11.Size = new Size(44, 15);
            label11.TabIndex = 22;
            label11.Text = "label11";
            // 
            // searchlbl
            // 
            searchlbl.AutoSize = true;
            searchlbl.Location = new Point(526, 123);
            searchlbl.Name = "searchlbl";
            searchlbl.Size = new Size(56, 15);
            searchlbl.TabIndex = 23;
            searchlbl.Text = "Search ID";
            // 
            // comboBox1
            // 
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(354, 56);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 23);
            comboBox1.TabIndex = 24;
            // 
            // panel1
            // 
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label11);
            panel1.Controls.Add(label8);
            panel1.Controls.Add(label9);
            panel1.Controls.Add(label10);
            panel1.Location = new Point(50, 149);
            panel1.Name = "panel1";
            panel1.Size = new Size(726, 236);
            panel1.TabIndex = 25;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(panel1);
            Controls.Add(comboBox1);
            Controls.Add(searchlbl);
            Controls.Add(sinfoLbl);
            Controls.Add(gpaLbl);
            Controls.Add(gradeLbl);
            Controls.Add(courseLbl);
            Controls.Add(nameLbl);
            Controls.Add(sidLbl);
            Controls.Add(searchBtn);
            Controls.Add(addBtn);
            Controls.Add(filterBtn);
            Controls.Add(delBtn);
            Controls.Add(calculateBtn);
            Controls.Add(loadBtn);
            Controls.Add(saveBtn);
            Controls.Add(searchTxt);
            Controls.Add(textBox4);
            Controls.Add(textBox2);
            Controls.Add(textBox1);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox4;
        private TextBox searchTxt;
        private Button saveBtn;
        private Button loadBtn;
        private Button calculateBtn;
        private Button delBtn;
        private Button filterBtn;
        private Button addBtn;
        private Button searchBtn;
        private Label sidLbl;
        private Label nameLbl;
        private Label courseLbl;
        private Label gradeLbl;
        private Label gpaLbl;
        private Label sinfoLbl;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Label label11;
        private Label searchlbl;
        private ComboBox comboBox1;
        private Panel panel1;
    }
}
